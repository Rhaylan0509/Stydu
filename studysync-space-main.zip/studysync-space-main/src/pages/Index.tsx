import { useState } from "react";
import Navigation from "@/components/Navigation";
import NotesEditor from "@/components/NotesEditor";
import ErrorsNotebook from "@/components/ErrorsNotebook";
import RepertoireNotebook from "@/components/RepertoireNotebook";

const Index = () => {
  const [activeTab, setActiveTab] = useState("notes");

  const renderActiveComponent = () => {
    switch (activeTab) {
      case "notes":
        return <NotesEditor />;
      case "errors":
        return <ErrorsNotebook />;
      case "repertoire":
        return <RepertoireNotebook />;
      default:
        return <NotesEditor />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-subtle">
      <div className="container mx-auto p-6">
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          <div className="lg:col-span-1">
            <Navigation activeTab={activeTab} setActiveTab={setActiveTab} />
          </div>
          <div className="lg:col-span-3">
            {renderActiveComponent()}
          </div>
        </div>
      </div>
    </div>
  );
};

export default Index;
