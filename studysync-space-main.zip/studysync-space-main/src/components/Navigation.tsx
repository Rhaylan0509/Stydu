import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { BookOpen, FileText, AlertCircle, Lightbulb } from "lucide-react";

interface NavigationProps {
  activeTab: string;
  setActiveTab: (tab: string) => void;
}

const Navigation = ({ activeTab, setActiveTab }: NavigationProps) => {
  const tabs = [
    { id: "notes", label: "Anotações", icon: FileText },
    { id: "errors", label: "Caderno de Erros", icon: AlertCircle },
    { id: "repertoire", label: "Repertório", icon: Lightbulb },
  ];

  return (
    <Card className="p-4 bg-gradient-subtle border-study-blue/20 shadow-elegant">
      <div className="flex items-center mb-6">
        <BookOpen className="h-8 w-8 text-primary mr-3" />
        <h1 className="text-2xl font-bold text-foreground">StudySync</h1>
      </div>
      
      <nav className="space-y-2">
        {tabs.map((tab) => {
          const Icon = tab.icon;
          return (
            <Button
              key={tab.id}
              variant={activeTab === tab.id ? "default" : "ghost"}
              className={`w-full justify-start transition-all duration-300 ${
                activeTab === tab.id 
                  ? "bg-primary text-primary-foreground shadow-lg" 
                  : "hover:bg-accent hover:text-accent-foreground"
              }`}
              onClick={() => setActiveTab(tab.id)}
            >
              <Icon className="mr-3 h-5 w-5" />
              {tab.label}
            </Button>
          );
        })}
      </nav>
    </Card>
  );
};

export default Navigation;