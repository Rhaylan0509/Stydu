import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Search, Lightbulb, Trash2, Star } from "lucide-react";

interface RepertoireEntry {
  id: string;
  title: string;
  category: string;
  thematicAxis: string;
  source: string;
  content: string;
  keywords: string[];
  rating: number;
  applications: string;
  createdAt: Date;
}

const RepertoireNotebook = () => {
  const [repertoires, setRepertoires] = useState<RepertoireEntry[]>([]);
  const [selectedRepertoire, setSelectedRepertoire] = useState<RepertoireEntry | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterCategory, setFilterCategory] = useState<string>("all");
  const [newKeyword, setNewKeyword] = useState("");

  useEffect(() => {
    const saved = localStorage.getItem("repertoireNotebook");
    if (saved) {
      const parsedRepertoires = JSON.parse(saved).map((repertoire: any) => ({
        ...repertoire,
        createdAt: new Date(repertoire.createdAt)
      }));
      setRepertoires(parsedRepertoires);
    }
  }, []);

  useEffect(() => {
    localStorage.setItem("repertoireNotebook", JSON.stringify(repertoires));
  }, [repertoires]);

  const createRepertoire = () => {
    const newRepertoire: RepertoireEntry = {
      id: Date.now().toString(),
      title: "Novo Repertório",
      category: "",
      thematicAxis: "",
      source: "",
      content: "",
      keywords: [],
      rating: 5,
      applications: "",
      createdAt: new Date()
    };
    setRepertoires(prev => [newRepertoire, ...prev]);
    setSelectedRepertoire(newRepertoire);
  };

  const updateRepertoire = (updatedRepertoire: Partial<RepertoireEntry>) => {
    if (!selectedRepertoire) return;
    
    const updated = {
      ...selectedRepertoire,
      ...updatedRepertoire
    };
    
    setRepertoires(prev => prev.map(repertoire => 
      repertoire.id === selectedRepertoire.id ? updated : repertoire
    ));
    setSelectedRepertoire(updated);
  };

  const deleteRepertoire = (repertoireId: string) => {
    setRepertoires(prev => prev.filter(repertoire => repertoire.id !== repertoireId));
    if (selectedRepertoire?.id === repertoireId) {
      setSelectedRepertoire(null);
    }
  };

  const addKeyword = () => {
    if (!newKeyword.trim() || !selectedRepertoire) return;
    
    const updatedKeywords = [...selectedRepertoire.keywords, newKeyword.trim()];
    updateRepertoire({ keywords: updatedKeywords });
    setNewKeyword("");
  };

  const removeKeyword = (keywordToRemove: string) => {
    if (!selectedRepertoire) return;
    
    const updatedKeywords = selectedRepertoire.keywords.filter(keyword => keyword !== keywordToRemove);
    updateRepertoire({ keywords: updatedKeywords });
  };

  const categories = [...new Set(repertoires.map(repertoire => repertoire.category).filter(Boolean))];
  
  const filteredRepertoires = repertoires.filter(repertoire => {
    const matchesSearch = repertoire.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         repertoire.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         repertoire.keywords.some(keyword => keyword.toLowerCase().includes(searchTerm.toLowerCase()));
    const matchesCategory = filterCategory === "all" || repertoire.category === filterCategory;
    return matchesSearch && matchesCategory;
  });

  const renderStars = (rating: number, onRatingChange?: (rating: number) => void) => {
    return (
      <div className="flex items-center gap-1">
        {[1, 2, 3, 4, 5].map(star => (
          <Star
            key={star}
            className={`h-4 w-4 cursor-pointer transition-colors ${
              star <= rating 
                ? "fill-yellow-400 text-yellow-400" 
                : "text-gray-300"
            }`}
            onClick={() => onRatingChange?.(star)}
          />
        ))}
      </div>
    );
  };

  return (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-foreground mb-2">Caderno de Repertório</h2>
        <p className="text-muted-foreground">Colete conhecimentos, citações e referências para enriquecer seus estudos</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[calc(100vh-200px)]">
        {/* Lista de Repertórios */}
        <Card className="p-4 bg-gradient-subtle border-study-blue/20 shadow-elegant">
          <div className="space-y-3 mb-4">
            <div className="flex items-center gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Buscar repertório..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Button onClick={createRepertoire} size="sm" className="bg-primary hover:bg-primary/90">
                <Plus className="h-4 w-4" />
              </Button>
            </div>
            
            <Select value={filterCategory} onValueChange={setFilterCategory}>
              <SelectTrigger>
                <SelectValue placeholder="Filtrar por categoria" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas as categorias</SelectItem>
                {categories.map(category => (
                  <SelectItem key={category} value={category}>
                    {category}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2 max-h-[calc(100vh-350px)] overflow-y-auto">
            {filteredRepertoires.map(repertoire => (
              <div
                key={repertoire.id}
                className={`p-3 rounded-lg cursor-pointer transition-all duration-300 ${
                  selectedRepertoire?.id === repertoire.id
                    ? "bg-primary text-primary-foreground"
                    : "bg-card hover:bg-accent"
                }`}
                onClick={() => setSelectedRepertoire(repertoire)}
              >
                <div className="flex items-center justify-between mb-2">
                  <h4 className="font-medium truncate">{repertoire.title}</h4>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={(e) => {
                      e.stopPropagation();
                      deleteRepertoire(repertoire.id);
                    }}
                    className="h-6 w-6 p-0 text-destructive hover:text-destructive"
                  >
                    <Trash2 className="h-3 w-3" />
                  </Button>
                </div>
                
                <div className="space-y-1">
                  {repertoire.category && (
                    <Badge variant="secondary" className="text-xs">
                      {repertoire.category}
                    </Badge>
                  )}
                  <div className="flex items-center justify-between">
                    {renderStars(repertoire.rating)}
                    {repertoire.source && (
                      <span className="text-xs opacity-70 truncate">{repertoire.source}</span>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* Editor */}
        {selectedRepertoire ? (
          <div className="lg:col-span-2 space-y-4">
            <Card className="p-6 bg-gradient-subtle border-study-blue/20 shadow-elegant">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <Input
                  value={selectedRepertoire.title}
                  onChange={(e) => updateRepertoire({ title: e.target.value })}
                  placeholder="Título do repertório..."
                  className="text-lg font-semibold md:col-span-2"
                />
                <Input
                  value={selectedRepertoire.category}
                  onChange={(e) => updateRepertoire({ category: e.target.value })}
                  placeholder="Categoria (ex: História, Literatura)..."
                />
                <Input
                  value={selectedRepertoire.thematicAxis}
                  onChange={(e) => updateRepertoire({ thematicAxis: e.target.value })}
                  placeholder="Eixo temático..."
                />
                <Input
                  value={selectedRepertoire.source}
                  onChange={(e) => updateRepertoire({ source: e.target.value })}
                  placeholder="Fonte (livro, artigo, etc.)..."
                />
                <div className="flex items-center gap-2">
                  <span className="text-sm font-medium">Relevância:</span>
                  {renderStars(selectedRepertoire.rating, (rating) => updateRepertoire({ rating }))}
                </div>
              </div>

              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-foreground mb-2 block">
                    💡 Conteúdo do Repertório
                  </label>
                  <Textarea
                    value={selectedRepertoire.content}
                    onChange={(e) => updateRepertoire({ content: e.target.value })}
                    placeholder="Descreva o conteúdo, citação, dado histórico, conceito, etc..."
                    className="min-h-[150px] resize-none"
                  />
                </div>

                <div>
                  <label className="text-sm font-medium text-foreground mb-2 block">
                    🔑 Palavras-chave
                  </label>
                  <div className="flex flex-wrap gap-2 mb-3">
                    {selectedRepertoire.keywords.map(keyword => (
                      <Badge
                        key={keyword}
                        variant="outline"
                        className="cursor-pointer"
                        onClick={() => removeKeyword(keyword)}
                      >
                        {keyword}
                        <Trash2 className="h-3 w-3 ml-1" />
                      </Badge>
                    ))}
                  </div>
                  <div className="flex items-center gap-2">
                    <Input
                      value={newKeyword}
                      onChange={(e) => setNewKeyword(e.target.value)}
                      onKeyPress={(e) => e.key === "Enter" && addKeyword()}
                      placeholder="Nova palavra-chave..."
                      className="flex-1"
                    />
                    <Button size="sm" onClick={addKeyword} variant="outline">
                      <Plus className="h-3 w-3" />
                    </Button>
                  </div>
                </div>

                <div>
                  <label className="text-sm font-medium text-foreground mb-2 block">
                    📚 Possíveis Aplicações
                  </label>
                  <Textarea
                    value={selectedRepertoire.applications}
                    onChange={(e) => updateRepertoire({ applications: e.target.value })}
                    placeholder="Em que contextos posso usar este repertório? Redações, provas, trabalhos..."
                    className="min-h-[100px] resize-none"
                  />
                </div>
              </div>

              <div className="text-xs text-muted-foreground mt-4">
                Criado em: {selectedRepertoire.createdAt.toLocaleString()}
              </div>
            </Card>
          </div>
        ) : (
          <div className="lg:col-span-2 flex items-center justify-center">
            <Card className="p-12 text-center bg-gradient-subtle border-study-blue/20">
              <Lightbulb className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">Selecione um repertório</h3>
              <p className="text-muted-foreground">
                Escolha um repertório da lista ou crie um novo para começar
              </p>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
};

export default RepertoireNotebook;