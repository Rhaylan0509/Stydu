import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Plus, Search, AlertCircle, Trash2, BookOpen, FileDown, Filter } from "lucide-react";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { Checkbox } from "@/components/ui/checkbox";
import jsPDF from "jspdf";
import QRCode from "qrcode";

interface ErrorEntry {
  id: string;
  title: string;
  tags: string[];
  classification: "Fácil" | "Médio" | "Difícil";
  banca: string;
  question: string;
  questionImage?: string;
  whatIDidWrong: string;
  resolution: string;
  videoLink?: string;
  createdAt: Date;
  nextReview: Date;
  status: "ativo" | "rever";
}

const ErrorsNotebook = () => {
  const [errors, setErrors] = useState<ErrorEntry[]>([]);
  const [selectedError, setSelectedError] = useState<ErrorEntry | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [filterTag, setFilterTag] = useState<string>("all");
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [newTag, setNewTag] = useState("");
  const [exportDialogOpen, setExportDialogOpen] = useState(false);
  const [exportFilters, setExportFilters] = useState({
    quantity: 10,
    classifications: [] as string[],
    tags: [] as string[],
    status: "all" as string
  });

  const calculateNextReview = (classification: "Fácil" | "Médio" | "Difícil", fromDate: Date = new Date()): Date => {
    const nextReview = new Date(fromDate);
    switch (classification) {
      case "Fácil":
        nextReview.setDate(nextReview.getDate() + 14); // 2 semanas
        break;
      case "Médio":
        nextReview.setDate(nextReview.getDate() + 15); // 15 dias
        break;
      case "Difícil":
        nextReview.setDate(nextReview.getDate() + 7); // 1 semana
        break;
    }
    return nextReview;
  };

  const getStatus = (nextReview: Date): "ativo" | "rever" => {
    return new Date() >= nextReview ? "rever" : "ativo";
  };

  useEffect(() => {
    const saved = localStorage.getItem("errorsNotebook");
    if (saved) {
      const parsedErrors = JSON.parse(saved).map((error: any) => {
        const nextReview = error.nextReview ? new Date(error.nextReview) : calculateNextReview(error.classification, new Date(error.createdAt));
        return {
          ...error,
          createdAt: new Date(error.createdAt),
          nextReview,
          status: getStatus(nextReview)
        };
      });
      setErrors(parsedErrors);
    }
  }, []);

  useEffect(() => {
    const interval = setInterval(() => {
      setErrors(prev => prev.map(error => ({
        ...error,
        status: getStatus(error.nextReview)
      })));
    }, 60000); // Atualiza a cada minuto
    return () => clearInterval(interval);
  }, []);

  useEffect(() => {
    localStorage.setItem("errorsNotebook", JSON.stringify(errors));
  }, [errors]);

  const createError = () => {
    const createdAt = new Date();
    const newError: ErrorEntry = {
      id: Date.now().toString(),
      title: "Nova Questão",
      tags: [],
      classification: "Médio",
      banca: "",
      question: "",
      questionImage: "",
      whatIDidWrong: "",
      resolution: "",
      videoLink: "",
      createdAt,
      nextReview: calculateNextReview("Médio", createdAt),
      status: "ativo"
    };
    setErrors(prev => [newError, ...prev]);
    setSelectedError(newError);
  };

  const updateError = (updatedError: Partial<ErrorEntry>) => {
    if (!selectedError) return;
    
    let updated = {
      ...selectedError,
      ...updatedError
    };

    // Se a classificação mudou, recalcula a próxima revisão
    if (updatedError.classification && updatedError.classification !== selectedError.classification) {
      updated.nextReview = calculateNextReview(updatedError.classification, updated.createdAt);
      updated.status = getStatus(updated.nextReview);
    }
    
    setErrors(prev => prev.map(error => 
      error.id === selectedError.id ? updated : error
    ));
    setSelectedError(updated);
  };

  const deleteError = (errorId: string) => {
    setErrors(prev => prev.filter(error => error.id !== errorId));
    if (selectedError?.id === errorId) {
      setSelectedError(null);
    }
  };

  const addTag = () => {
    if (!newTag.trim() || !selectedError) return;
    
    const updatedTags = [...selectedError.tags, newTag.trim()];
    updateError({ tags: updatedTags });
    setNewTag("");
  };

  const removeTag = (tagToRemove: string) => {
    if (!selectedError) return;
    
    const updatedTags = selectedError.tags.filter(tag => tag !== tagToRemove);
    updateError({ tags: updatedTags });
  };

  const allTags = [...new Set(errors.flatMap(error => error.tags).filter(Boolean))];
  
  const filteredErrors = errors.filter(error => {
    const matchesSearch = error.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         error.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase())) ||
                         error.question.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesTag = filterTag === "all" || error.tags.includes(filterTag);
    const matchesStatus = filterStatus === "all" || error.status === filterStatus;
    return matchesSearch && matchesTag && matchesStatus;
  });

  const exportToPDF = async () => {
    let filtered = [...errors];
    
    // Aplicar filtros
    if (exportFilters.classifications.length > 0) {
      filtered = filtered.filter(e => exportFilters.classifications.includes(e.classification));
    }
    if (exportFilters.tags.length > 0) {
      filtered = filtered.filter(e => e.tags.some(tag => exportFilters.tags.includes(tag)));
    }
    if (exportFilters.status !== "all") {
      filtered = filtered.filter(e => e.status === exportFilters.status);
    }
    
    // Limitar quantidade
    filtered = filtered.slice(0, exportFilters.quantity);
    
    if (filtered.length === 0) {
      alert("Nenhuma questão encontrada com os filtros selecionados");
      return;
    }

    const pdf = new jsPDF();
    const pageWidth = pdf.internal.pageSize.getWidth();
    const pageHeight = pdf.internal.pageSize.getHeight();
    const margin = 20;
    const contentWidth = pageWidth - 2 * margin;
    
    // Página inicial
    pdf.setFontSize(24);
    pdf.text("CADERNO DE ERROS", pageWidth / 2, 80, { align: "center" });
    
    pdf.setFontSize(14);
    const tagsText = exportFilters.tags.length > 0 ? exportFilters.tags.join(", ") : "Todas as tags";
    const nivelText = exportFilters.classifications.length > 0 ? exportFilters.classifications.join(", ") : "Todos os níveis";
    pdf.text(`${tagsText} | ${nivelText}`, pageWidth / 2, 100, { align: "center" });
    
    pdf.setFontSize(10);
    const currentDate = new Date().toLocaleDateString("pt-BR");
    pdf.text(currentDate, pageWidth - margin, pageHeight - margin, { align: "right" });
    pdf.text("StudyPro", pageWidth - margin, pageHeight - margin + 5, { align: "right" });
    
    // Questões - todas na mesma página (ou páginas contínuas)
    pdf.addPage();
    let yPos = margin + 10;
    let pageNumber = 2;
    
    filtered.forEach((error, index) => {
      // Verificar se precisa de nova página
      if (yPos > pageHeight - 60) {
        pdf.setFontSize(9);
        pdf.text(`Página ${pageNumber}`, pageWidth / 2, pageHeight - 10, { align: "center" });
        pdf.addPage();
        yPos = margin + 10;
        pageNumber++;
      }
      
      pdf.setFontSize(11);
      pdf.setFont(undefined, "bold");
      
      // Formato: (Banca) Questão X
      const bancaText = error.banca ? `(${error.banca}) ` : "";
      pdf.text(`${bancaText}Questão ${index + 1}`, margin, yPos);
      pdf.setFont(undefined, "normal");
      yPos += 8;
      
      // Questão
      pdf.setFontSize(10);
      const questionLines = pdf.splitTextToSize(error.question || "Sem texto da questão", contentWidth);
      pdf.text(questionLines, margin, yPos);
      yPos += questionLines.length * 5 + 5;
      
      // URL da imagem se houver
      if (error.questionImage) {
        pdf.setFontSize(8);
        pdf.text(`[Imagem: ${error.questionImage}]`, margin, yPos);
        yPos += 6;
      }
      
      yPos += 10; // Espaço entre questões
    });
    
    // Adicionar número da última página de questões
    pdf.setFontSize(9);
    pdf.text(`Página ${pageNumber}`, pageWidth / 2, pageHeight - 10, { align: "center" });
    
    // Página de resoluções
    pdf.addPage();
    pdf.setFontSize(16);
    pdf.text("RESOLUÇÕES", pageWidth / 2, margin + 10, { align: "center" });
    
    yPos = margin + 30;
    pageNumber++;
    
    for (const [index, error] of filtered.entries()) {
      if (yPos > pageHeight - 60) {
        pdf.setFontSize(9);
        pdf.text(`Página ${pageNumber}`, pageWidth / 2, pageHeight - 10, { align: "center" });
        pdf.addPage();
        yPos = margin + 10;
        pageNumber++;
      }
      
      pdf.setFontSize(12);
      pdf.setFont(undefined, "bold");
      pdf.text(`Questão ${index + 1}:`, margin, yPos);
      pdf.setFont(undefined, "normal");
      yPos += 8;
      
      pdf.setFontSize(10);
      
      // O que errei
      if (error.whatIDidWrong) {
        pdf.setFont(undefined, "bold");
        pdf.text("O que eu errei:", margin, yPos);
        pdf.setFont(undefined, "normal");
        yPos += 6;
        const wrongLines = pdf.splitTextToSize(error.whatIDidWrong, contentWidth);
        pdf.text(wrongLines, margin, yPos);
        yPos += wrongLines.length * 5 + 5;
      }
      
      // Resolução
      if (error.resolution) {
        pdf.setFont(undefined, "bold");
        pdf.text("Resolução:", margin, yPos);
        pdf.setFont(undefined, "normal");
        yPos += 6;
        const resolutionLines = pdf.splitTextToSize(error.resolution, contentWidth - 40);
        pdf.text(resolutionLines, margin, yPos);
        yPos += resolutionLines.length * 5 + 5;
      }
      
      // Link de vídeo e QR Code
      if (error.videoLink) {
        try {
          const qrCodeDataUrl = await QRCode.toDataURL(error.videoLink, { width: 60, margin: 1 });
          
          pdf.setFont(undefined, "bold");
          pdf.text("Vídeo:", margin, yPos);
          pdf.setFont(undefined, "normal");
          yPos += 6;
          
          // Link do vídeo
          pdf.setFontSize(8);
          pdf.setTextColor(0, 0, 255);
          pdf.textWithLink(error.videoLink, margin, yPos, { url: error.videoLink });
          pdf.setTextColor(0, 0, 0);
          
          // QR Code ao lado
          pdf.addImage(qrCodeDataUrl, "PNG", pageWidth - margin - 20, yPos - 15, 20, 20);
          
          yPos += 8;
        } catch (error) {
          console.error("Erro ao gerar QR Code:", error);
        }
      }
      
      yPos += 10; // Espaço entre resoluções
    }
    
    // Adicionar número da última página
    pdf.setFontSize(9);
    pdf.text(`Página ${pageNumber}`, pageWidth / 2, pageHeight - 10, { align: "center" });
    
    pdf.save(`caderno-de-erros-${new Date().toISOString().split('T')[0]}.pdf`);
    setExportDialogOpen(false);
  };

  const getClassificationColor = (classification: string) => {
    switch (classification) {
      case "Fácil": return "bg-green-100 text-green-800";
      case "Médio": return "bg-yellow-100 text-yellow-800";
      case "Difícil": return "bg-red-100 text-red-800";
      default: return "bg-gray-100 text-gray-800";
    }
  };

  return (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-foreground mb-2">Caderno de Erros</h2>
        <p className="text-muted-foreground">Aprenda com seus erros e transforme-os em conhecimento</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[calc(100vh-200px)]">
        {/* Lista de Erros */}
        <Card className="p-4 bg-gradient-subtle border-study-blue/20 shadow-elegant">
          <div className="space-y-3 mb-4">
            <div className="flex items-center gap-2">
              <div className="relative flex-1">
                <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                <Input
                  placeholder="Buscar erros..."
                  value={searchTerm}
                  onChange={(e) => setSearchTerm(e.target.value)}
                  className="pl-10"
                />
              </div>
              <Button onClick={createError} size="sm" className="bg-primary hover:bg-primary/90">
                <Plus className="h-4 w-4" />
              </Button>
            </div>
            
            <div className="grid grid-cols-2 gap-2">
              <Select value={filterTag} onValueChange={setFilterTag}>
                <SelectTrigger>
                  <SelectValue placeholder="Filtrar por tag" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas as tags</SelectItem>
                  {allTags.map(tag => (
                    <SelectItem key={tag} value={tag}>
                      {tag}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              
              <Select value={filterStatus} onValueChange={setFilterStatus}>
                <SelectTrigger>
                  <SelectValue placeholder="Status" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos</SelectItem>
                  <SelectItem value="ativo">🟢 Ativo</SelectItem>
                  <SelectItem value="rever">🔴 Rever</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <Dialog open={exportDialogOpen} onOpenChange={setExportDialogOpen}>
              <DialogTrigger asChild>
                <Button variant="outline" size="sm" className="w-full">
                  <FileDown className="h-4 w-4 mr-2" />
                  Exportar PDF
                </Button>
              </DialogTrigger>
              <DialogContent className="max-w-md">
                <DialogHeader>
                  <DialogTitle>Exportar Questões em PDF</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 py-4">
                  <div>
                    <label className="text-sm font-medium mb-2 block">Quantidade de questões</label>
                    <Input
                      type="number"
                      min="1"
                      value={exportFilters.quantity}
                      onChange={(e) => setExportFilters(prev => ({ ...prev, quantity: parseInt(e.target.value) || 1 }))}
                    />
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium mb-2 block">Níveis</label>
                    <div className="space-y-2">
                      {["Fácil", "Médio", "Difícil"].map(level => (
                        <div key={level} className="flex items-center space-x-2">
                          <Checkbox
                            checked={exportFilters.classifications.includes(level)}
                            onCheckedChange={(checked) => {
                              setExportFilters(prev => ({
                                ...prev,
                                classifications: checked
                                  ? [...prev.classifications, level]
                                  : prev.classifications.filter(c => c !== level)
                              }));
                            }}
                          />
                          <label className="text-sm">{level}</label>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium mb-2 block">Tags</label>
                    <div className="space-y-2 max-h-32 overflow-y-auto">
                      {allTags.map(tag => (
                        <div key={tag} className="flex items-center space-x-2">
                          <Checkbox
                            checked={exportFilters.tags.includes(tag)}
                            onCheckedChange={(checked) => {
                              setExportFilters(prev => ({
                                ...prev,
                                tags: checked
                                  ? [...prev.tags, tag]
                                  : prev.tags.filter(t => t !== tag)
                              }));
                            }}
                          />
                          <label className="text-sm">{tag}</label>
                        </div>
                      ))}
                    </div>
                  </div>
                  
                  <div>
                    <label className="text-sm font-medium mb-2 block">Status</label>
                    <Select value={exportFilters.status} onValueChange={(value) => setExportFilters(prev => ({ ...prev, status: value }))}>
                      <SelectTrigger>
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Todos</SelectItem>
                        <SelectItem value="ativo">🟢 Ativo</SelectItem>
                        <SelectItem value="rever">🔴 Rever</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <Button onClick={exportToPDF} className="w-full">
                    Gerar PDF
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
          </div>

          <div className="space-y-2 max-h-[calc(100vh-350px)] overflow-y-auto">
            {filteredErrors.map(error => (
              <div
                key={error.id}
                className={`p-3 rounded-lg cursor-pointer transition-all duration-300 ${
                  selectedError?.id === error.id
                    ? "bg-primary text-primary-foreground"
                    : "bg-card hover:bg-accent"
                }`}
                onClick={() => setSelectedError(error)}
              >
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <span className="text-lg">{error.status === "ativo" ? "🟢" : "🔴"}</span>
                    <h4 className="font-medium truncate">{error.title}</h4>
                  </div>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={(e) => {
                      e.stopPropagation();
                      deleteError(error.id);
                    }}
                    className="h-6 w-6 p-0 text-destructive hover:text-destructive"
                  >
                    <Trash2 className="h-3 w-3" />
                  </Button>
                </div>
                <div className="flex flex-wrap gap-1 mb-1">
                  {error.tags.slice(0, 2).map(tag => (
                    <Badge key={tag} variant="secondary" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                  {error.tags.length > 2 && (
                    <Badge variant="secondary" className="text-xs">
                      +{error.tags.length - 2}
                    </Badge>
                  )}
                </div>
                <Badge className={`text-xs ${getClassificationColor(error.classification)}`}>
                  {error.classification}
                </Badge>
              </div>
            ))}
          </div>
        </Card>

        {/* Editor */}
        {selectedError ? (
          <div className="lg:col-span-2 space-y-4">
            <Card className="p-6 bg-gradient-subtle border-study-blue/20 shadow-elegant">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <Input
                  value={selectedError.title}
                  onChange={(e) => updateError({ title: e.target.value })}
                  placeholder="Título da questão..."
                  className="text-lg font-semibold md:col-span-2"
                />
                <Select
                  value={selectedError.classification}
                  onValueChange={(value: "Fácil" | "Médio" | "Difícil") => 
                    updateError({ classification: value })
                  }
                >
                  <SelectTrigger>
                    <SelectValue placeholder="Classificação" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Fácil">Fácil</SelectItem>
                    <SelectItem value="Médio">Médio</SelectItem>
                    <SelectItem value="Difícil">Difícil</SelectItem>
                  </SelectContent>
                </Select>
                <Input
                  value={selectedError.banca}
                  onChange={(e) => updateError({ banca: e.target.value })}
                  placeholder="Banca (ex: ENEM, Fuvest)..."
                />
              </div>

              <div className="space-y-4">
                <div>
                  <label className="text-sm font-medium text-foreground mb-2 block">
                    🔑 Tags da Questão
                  </label>
                  <div className="flex flex-wrap gap-2 mb-3">
                    {selectedError.tags.map(tag => (
                      <Badge
                        key={tag}
                        variant="outline"
                        className="cursor-pointer"
                        onClick={() => removeTag(tag)}
                      >
                        {tag}
                        <Trash2 className="h-3 w-3 ml-1" />
                      </Badge>
                    ))}
                  </div>
                  <div className="flex items-center gap-2">
                    <Input
                      value={newTag}
                      onChange={(e) => setNewTag(e.target.value)}
                      onKeyPress={(e) => e.key === "Enter" && addTag()}
                      placeholder="Nova tag..."
                      className="flex-1"
                    />
                    <Button size="sm" onClick={addTag} variant="outline">
                      <Plus className="h-3 w-3" />
                    </Button>
                  </div>
                </div>

                <div>
                  <label className="text-sm font-medium text-foreground mb-2 block">
                    📝 Questão
                  </label>
                  <Textarea
                    value={selectedError.question}
                    onChange={(e) => updateError({ question: e.target.value })}
                    placeholder="Cole ou digite a questão aqui..."
                    className="min-h-[150px] resize-none"
                  />
                  <Input
                    value={selectedError.questionImage || ""}
                    onChange={(e) => updateError({ questionImage: e.target.value })}
                    placeholder="URL da imagem da questão (opcional)"
                    className="mt-2"
                  />
                </div>

                <div>
                  <label className="text-sm font-medium text-foreground mb-2 block">
                    ❌ O Que Eu Errei
                  </label>
                  <Textarea
                    value={selectedError.whatIDidWrong}
                    onChange={(e) => updateError({ whatIDidWrong: e.target.value })}
                    placeholder="Descreva o erro que você cometeu..."
                    className="min-h-[120px] resize-none"
                  />
                </div>

                <div>
                  <label className="text-sm font-medium text-foreground mb-2 block">
                    ✅ Resolução
                  </label>
                  <Textarea
                    value={selectedError.resolution}
                    onChange={(e) => updateError({ resolution: e.target.value })}
                    placeholder="Explique a resolução correta..."
                    className="min-h-[120px] resize-none"
                  />
                  <Input
                    value={selectedError.videoLink || ""}
                    onChange={(e) => updateError({ videoLink: e.target.value })}
                    placeholder="Link do vídeo de resolução (opcional)"
                    className="mt-2"
                  />
                </div>
              </div>

              <div className="flex justify-between items-center text-xs text-muted-foreground mt-4">
                <span>Criado em: {selectedError.createdAt.toLocaleString()}</span>
                <span className="flex items-center gap-2">
                  {selectedError.status === "ativo" ? "🟢 Ativo" : "🔴 Rever"} | 
                  Próxima revisão: {selectedError.nextReview.toLocaleDateString("pt-BR")}
                </span>
              </div>
            </Card>
          </div>
        ) : (
          <div className="lg:col-span-2 flex items-center justify-center">
            <Card className="p-12 text-center bg-gradient-subtle border-study-blue/20">
              <AlertCircle className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">Selecione um erro</h3>
              <p className="text-muted-foreground">
                Escolha um erro da lista ou registre um novo para começar
              </p>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
};

export default ErrorsNotebook;