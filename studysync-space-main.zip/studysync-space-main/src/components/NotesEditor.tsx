import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Plus, Search, Tag, Trash2, FileText } from "lucide-react";

interface Note {
  id: string;
  title: string;
  content: string;
  tags: string[];
  createdAt: Date;
  updatedAt: Date;
}

const NotesEditor = () => {
  const [notes, setNotes] = useState<Note[]>([]);
  const [selectedNote, setSelectedNote] = useState<Note | null>(null);
  const [searchTerm, setSearchTerm] = useState("");
  const [newTag, setNewTag] = useState("");

  useEffect(() => {
    const saved = localStorage.getItem("studyNotes");
    if (saved) {
      const parsedNotes = JSON.parse(saved).map((note: any) => ({
        ...note,
        createdAt: new Date(note.createdAt),
        updatedAt: new Date(note.updatedAt)
      }));
      setNotes(parsedNotes);
    }
  }, []);

  useEffect(() => {
    localStorage.setItem("studyNotes", JSON.stringify(notes));
  }, [notes]);

  const createNote = () => {
    const newNote: Note = {
      id: Date.now().toString(),
      title: "Nova Anotação",
      content: "",
      tags: [],
      createdAt: new Date(),
      updatedAt: new Date()
    };
    setNotes(prev => [newNote, ...prev]);
    setSelectedNote(newNote);
  };

  const updateNote = (updatedNote: Partial<Note>) => {
    if (!selectedNote) return;
    
    const updated = {
      ...selectedNote,
      ...updatedNote,
      updatedAt: new Date()
    };
    
    setNotes(prev => prev.map(note => 
      note.id === selectedNote.id ? updated : note
    ));
    setSelectedNote(updated);
  };

  const deleteNote = (noteId: string) => {
    setNotes(prev => prev.filter(note => note.id !== noteId));
    if (selectedNote?.id === noteId) {
      setSelectedNote(null);
    }
  };

  const addTag = () => {
    if (!newTag.trim() || !selectedNote) return;
    
    const updatedTags = [...selectedNote.tags, newTag.trim()];
    updateNote({ tags: updatedTags });
    setNewTag("");
  };

  const removeTag = (tagToRemove: string) => {
    if (!selectedNote) return;
    
    const updatedTags = selectedNote.tags.filter(tag => tag !== tagToRemove);
    updateNote({ tags: updatedTags });
  };

  const filteredNotes = notes.filter(note =>
    note.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
    note.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
    note.tags.some(tag => tag.toLowerCase().includes(searchTerm.toLowerCase()))
  );

  return (
    <div className="space-y-6">
      <div className="text-center mb-8">
        <h2 className="text-3xl font-bold text-foreground mb-2">Bloco de Anotações</h2>
        <p className="text-muted-foreground">Organize seus estudos e ideias com total liberdade</p>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 h-[calc(100vh-200px)]">
        {/* Lista de Notas */}
        <Card className="p-4 bg-gradient-subtle border-study-blue/20 shadow-elegant">
          <div className="flex items-center gap-2 mb-4">
            <div className="relative flex-1">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Buscar anotações..."
                value={searchTerm}
                onChange={(e) => setSearchTerm(e.target.value)}
                className="pl-10"
              />
            </div>
            <Button onClick={createNote} size="sm" className="bg-primary hover:bg-primary/90">
              <Plus className="h-4 w-4" />
            </Button>
          </div>

          <div className="space-y-2 max-h-[calc(100vh-300px)] overflow-y-auto">
            {filteredNotes.map(note => (
              <div
                key={note.id}
                className={`p-3 rounded-lg cursor-pointer transition-all duration-300 ${
                  selectedNote?.id === note.id
                    ? "bg-primary text-primary-foreground"
                    : "bg-card hover:bg-accent"
                }`}
                onClick={() => setSelectedNote(note)}
              >
                <div className="flex items-center justify-between mb-1">
                  <h4 className="font-medium truncate">{note.title}</h4>
                  <Button
                    size="sm"
                    variant="ghost"
                    onClick={(e) => {
                      e.stopPropagation();
                      deleteNote(note.id);
                    }}
                    className="h-6 w-6 p-0 text-destructive hover:text-destructive"
                  >
                    <Trash2 className="h-3 w-3" />
                  </Button>
                </div>
                <p className="text-sm opacity-70 truncate">{note.content}</p>
                <div className="flex flex-wrap gap-1 mt-2">
                  {note.tags.slice(0, 2).map(tag => (
                    <Badge key={tag} variant="secondary" className="text-xs">
                      {tag}
                    </Badge>
                  ))}
                  {note.tags.length > 2 && (
                    <Badge variant="secondary" className="text-xs">
                      +{note.tags.length - 2}
                    </Badge>
                  )}
                </div>
              </div>
            ))}
          </div>
        </Card>

        {/* Editor */}
        {selectedNote ? (
          <div className="lg:col-span-2 space-y-4">
            <Card className="p-6 bg-gradient-subtle border-study-blue/20 shadow-elegant">
              <Input
                value={selectedNote.title}
                onChange={(e) => updateNote({ title: e.target.value })}
                className="text-xl font-semibold mb-4 border-none bg-transparent p-0 focus:ring-0"
                placeholder="Título da anotação..."
              />

              <div className="flex flex-wrap gap-2 mb-4">
                {selectedNote.tags.map(tag => (
                  <Badge
                    key={tag}
                    variant="outline"
                    className="cursor-pointer"
                    onClick={() => removeTag(tag)}
                  >
                    <Tag className="h-3 w-3 mr-1" />
                    {tag}
                    <Trash2 className="h-3 w-3 ml-1" />
                  </Badge>
                ))}
                <div className="flex items-center gap-2">
                  <Input
                    value={newTag}
                    onChange={(e) => setNewTag(e.target.value)}
                    onKeyPress={(e) => e.key === "Enter" && addTag()}
                    placeholder="Nova tag..."
                    className="w-24"
                    size={newTag.length || 10}
                  />
                  <Button size="sm" onClick={addTag} variant="outline">
                    <Plus className="h-3 w-3" />
                  </Button>
                </div>
              </div>

              <Textarea
                value={selectedNote.content}
                onChange={(e) => updateNote({ content: e.target.value })}
                placeholder="Comece a escrever suas anotações aqui..."
                className="min-h-[400px] resize-none border-none bg-transparent p-0 focus:ring-0"
              />

              <div className="text-xs text-muted-foreground mt-4">
                Última atualização: {selectedNote.updatedAt.toLocaleString()}
              </div>
            </Card>
          </div>
        ) : (
          <div className="lg:col-span-2 flex items-center justify-center">
            <Card className="p-12 text-center bg-gradient-subtle border-study-blue/20">
              <FileText className="h-16 w-16 text-muted-foreground mx-auto mb-4" />
              <h3 className="text-xl font-semibold mb-2">Selecione uma anotação</h3>
              <p className="text-muted-foreground">
                Escolha uma anotação da lista ou crie uma nova para começar
              </p>
            </Card>
          </div>
        )}
      </div>
    </div>
  );
};

export default NotesEditor;